extends Node2D

const PipeCursor = preload("res://scripts/pipe_cursor.gd")
const PlanetViewController = preload("res://scripts/planet_view_controller.gd")
const GovernedRegion = preload("res://scripts/governed_region.gd")
const REGION_SCENE: PackedScene = preload("res://scenes/world/governed_region.tscn")
const MucusField = preload("res://scripts/mucus_field.gd")
const MUCUS_SCENE: PackedScene = preload("res://scenes/effects/mucus_field.tscn")
const DRILL_SCENE: PackedScene = preload("res://scenes/world/drill_monster.tscn")
const TREASURE_SCENE: PackedScene = preload("res://scenes/effects/drill_treasure.tscn")
const DrillTreasure = preload("res://scripts/drill_treasure.gd")
const NestMucusArea = preload("res://scripts/nest_mucus_area.gd")
const NEST_MUCUS_SCENE: PackedScene = preload("res://scenes/effects/nest_mucus_area.tscn")
const VacuumAudio = preload("res://scripts/vacuum_audio.gd")
const GiantFusion = preload("res://scripts/giant_slime_fusion.gd")
const GiantHarvestEffect = preload("res://scripts/giant_harvest_effect.gd")
const MonsterAudio = preload("res://scripts/monster_audio.gd")
const PlanetAudio = preload("res://scripts/planet_audio.gd")
const TechnologyPage = preload("res://scripts/ui/technology_page.gd")

enum ToolMode { PIPE, NET }
enum NetPhase { IDLE, CASTING, CLOSING, RESULT }

@export var slime_scene: PackedScene
@export var giant_slime_scene: PackedScene
@export var nest_scene: PackedScene
@export var collection_scene: PackedScene
@export var giant_harvest_scene: PackedScene
@export_range(0.1, 1.0, 0.05) var net_result_seconds: float = 0.30

var selected_nest_id: int = -1
var _active_tool: ToolMode = ToolMode.PIPE
var _net_phase: NetPhase = NetPhase.IDLE
var _net_elapsed: float = 0.0
var _net_origin: Vector2 = Vector2.ZERO
var _net_anchor: Vector2 = Vector2.ZERO
var _net_caught_count: int = 0
var _tool_pointer: Vector2 = Vector2.ZERO
var _nest_views: Array[NestView] = []
var _slimes: Array[PrototypeSlime] = []
var _capture_targets: Array[PrototypeSlime] = []
var _was_holding: bool = false
var _view_blocks_tool_until_release: bool = false
var _window_has_focus: bool = true
var _spawn_directions: Dictionary = {}
var _regions: Array[GovernedRegion] = []
var _mucus_trails: Array[MucusField] = []
var _active_mucus_trails: Dictionary = {}
var _nest_mucus_areas: Array[NestMucusArea] = []
var _completion_tween: Tween
var _status_tween: Tween
var _hud_refresh_queued: bool = false
var _overview_sample_elapsed: float = 0.0
var _giant_check_elapsed: float = 0.0
var _giant_harvest: GiantHarvestEffect
var _site_random: RandomNumberGenerator = RandomNumberGenerator.new()
var _nest_site_angles: PackedFloat32Array = PackedFloat32Array()
var _nest_site_jitter: float = 0.0
var _nest_site_distance: float = 0.0
var _vacuum_audio: VacuumAudio
var _monster_audio: MonsterAudio
var _planet_audio: PlanetAudio
var _opening_nests: bool = false
var _population_by_species: Dictionary = {}

@onready var run: PrototypeRun = $Run
@onready var _world: Node2D = $World
@onready var _view: PlanetViewController = %PlanetViewController
@onready var _planet: PlanetSurface = %PlanetSurface
@onready var _nests: Node2D = %Nests
@onready var _region_root: Node2D = %Regions
@onready var _slime_root: Node2D = %Slimes
@onready var _effects: Node2D = %Effects
@onready var _mucus_root: Node2D = %GroundMucus
@onready var _overview: OverviewEcology = %OverviewEcology
@onready var _pipe: PipeCursor = %Pipe
@onready var _net: CaptureNet = %CaptureNet
@onready var _layout: DiskDemoLayout = %Interface
@onready var _candy_label: Label = %CandyLabel
@onready var _passive_label: Label = %PassiveLabel
@onready var _progress_label: Label = %ProgressLabel
@onready var _progress_bar: ProgressBar = %ProgressBar
@onready var _tool_level_label: Label = %ToolLevelLabel
@onready var _tool_stats_label: Label = %ToolStatsLabel
@onready var _tool_button: Button = %ToolButton
@onready var _pipe_button: Button = %PipeToolButton
@onready var _net_button: Button = %NetToolButton
@onready var _quick_pipe_button: Button = %QuickPipeButton
@onready var _quick_net_button: Button = %QuickNetButton
@onready var _nest_title_label: Label = %NestTitleLabel
@onready var _nest_level_label: Label = %NestLevelLabel
@onready var _nest_benefit_label: Label = %NestBenefitLabel
@onready var _nest_button: Button = %NestButton
@onready var _status_label: Label = %StatusLabel
@onready var _completion: Control = %Completion
@onready var _completion_title: Label = %CompletionTitle
@onready var _completion_detail: Label = %CompletionDetail
@onready var _collect_sound: AudioStreamPlayer = $Audio/CollectSound
@onready var _upgrade_sound: AudioStreamPlayer = $Audio/UpgradeSound
@onready var _tame_sound: AudioStreamPlayer = $Audio/TameSound
@onready var _finish_sound: AudioStreamPlayer = $Audio/FinishSound


func _ready() -> void:
	assert(slime_scene != null and nest_scene != null and collection_scene != null)
	assert(giant_slime_scene != null, "Fusion requires the reusable giant slime scene.")
	assert(giant_harvest_scene != null, "Giant capture requires its harvest effect scene.")
	GameAudio.play_music("event:/Mx_GamePlay")
	_vacuum_audio = VacuumAudio.new()
	_vacuum_audio.name = "VacuumAudio"
	$Audio.add_child(_vacuum_audio)
	_monster_audio = MonsterAudio.new()
	_monster_audio.name = "MonsterAudio"
	$Audio.add_child(_monster_audio)
	_planet_audio = PlanetAudio.new()
	_planet_audio.name = "PlanetAudio"
	$Audio.add_child(_planet_audio)
	get_viewport().physics_object_picking = true
	run.economy_changed.connect(_queue_hud_refresh)
	run.base_value_changed.connect(_refresh_monster_rewards)
	run.nest_added.connect(_on_nest_added)
	run.nest_spawn_requested.connect(_on_nest_spawn_requested)
	run.nest_changed.connect(_on_nest_changed)
	run.slime_requested.connect(_on_slime_requested)
	run.goal_completed.connect(_on_goal_completed)
	run.automatic_income_received.connect(_on_automatic_income_received)
	_layout.quick_upgrade_requested.connect(_on_quick_upgrade)
	_layout.technology_upgrade_requested.connect(_on_technology_upgrade)
	_register_purchase_sounds()
	_tool_button.pressed.connect(_on_tool_upgrade)
	_pipe_button.pressed.connect(_select_tool.bind(ToolMode.PIPE))
	_net_button.pressed.connect(_select_tool.bind(ToolMode.NET))
	_quick_pipe_button.pressed.connect(_select_tool.bind(ToolMode.PIPE))
	_quick_net_button.pressed.connect(_select_tool.bind(ToolMode.NET))
	_nest_button.pressed.connect(_on_nest_upgrade)
	_layout.interaction_panel_changed.connect(_cancel_view_drag)
	_view.view_changed.connect(_sync_view_presentation)
	_view.projection_changed.connect(_sync_view_projection)
	%RestartButton.pressed.connect(restart_run)
	%ReplayButton.pressed.connect(restart_run)
	%CloseVictoryButton.pressed.connect(_close_victory)
	_overview.configure(_planet, _world)
	RenderingServer.set_default_clear_color(Color("e9e8df"))
	get_viewport().size_changed.connect(_apply_layout)
	get_window().focus_exited.connect(_on_window_focus_exited)
	get_window().focus_entered.connect(_on_window_focus_entered)
	_apply_layout()
	restart_run()


func _process(delta: float) -> void:
	var pointer: Vector2 = get_viewport().get_mouse_position()
	_update_nest_hover(pointer)
	_update_overview_hover(pointer)
	run.advance(delta)
	_advance_giant_fusion(delta)
	if _view.is_overview():
		_overview_sample_elapsed += delta
		if _overview_sample_elapsed >= 0.4:
			_refresh_overview()
	_layout.refresh_timers(run)
	_advance_ground_mucus(delta)
	_advance_monster_chatter(delta)
	_planet_audio.update_rotation(delta, _view.is_dragging(), _world.rotation)
	var world_position: Vector2 = _world.to_local(get_global_mouse_position())
	var holding: bool = Input.is_mouse_button_pressed(MOUSE_BUTTON_LEFT)
	if not holding and not _view.is_dragging():
		_view_blocks_tool_until_release = false
	holding = holding and not _view.is_dragging() and not _view_blocks_tool_until_release
	_drive_tool(delta, world_position, holding)


func _update_overview_hover(pointer: Vector2) -> void:
	_overview.update_hover(
		pointer,
		(
			_window_has_focus
			and _view.is_overview()
			and not _view.is_transitioning()
			and not _view.is_dragging()
			and get_viewport_rect().has_point(pointer)
			and not _layout.is_over_ui(pointer)
			and get_viewport().gui_get_hovered_control() == null
		)
	)


func _drive_tool(delta: float, pointer: Vector2, holding: bool) -> void:
	var just_pressed: bool = holding and not _was_holding
	_tool_pointer = pointer
	_pipe.visible = _active_tool == ToolMode.PIPE and _can_collect(pointer, run.get_pipe_radius())
	if _active_tool == ToolMode.PIPE:
		var tool_radius: float = run.get_pipe_radius()
		var capturing: bool = _can_collect(pointer, tool_radius)
		_pipe.radius = tool_radius
		_pipe.set_tool_state(pointer, pointer, capturing)
		_capture_at(delta, pointer, capturing)
	else:
		_capture_at(delta, pointer, false)
		if (
			just_pressed
			and _net_phase == NetPhase.IDLE
			and _can_collect(pointer, run.get_net_radius())
		):
			_start_net(pointer)
	_advance_net(delta)
	if _view.is_overview() or _view.is_transitioning():
		_net.hide()
	if _net_phase == NetPhase.IDLE and not _can_collect(pointer, run.get_net_radius()):
		_net.hide()
	_was_holding = holding


func _start_net(pointer: Vector2) -> void:
	if not run.begin_net_cast():
		return
	_net_phase = NetPhase.CASTING
	_net_elapsed = 0.0
	_net_anchor = pointer
	_net_caught_count = 0
	var direction: Vector2 = pointer.normalized()
	if direction.is_zero_approx():
		direction = Vector2.UP
	_net_origin = direction * (_planet.radius + 80.0)
	_net.show_cast(_net_origin, run.get_net_radius(), 0.0)


func _advance_net(delta: float) -> void:
	var net_radius: float = run.get_net_radius()
	match _net_phase:
		NetPhase.CASTING:
			_net_elapsed += delta
			var progress: float = clampf(_net_elapsed / _net.cast_seconds, 0.0, 1.0)
			_net.show_cast(_net_origin.lerp(_net_anchor, progress), net_radius, progress)
			if progress >= 1.0:
				_net_phase = NetPhase.CLOSING
				_net_elapsed = 0.0
		NetPhase.CLOSING:
			_net_elapsed += delta
			for slime: PrototypeSlime in _slimes:
				if slime.get_capture_point().distance_to(_net_anchor) <= net_radius:
					slime.apply_attraction(delta, _net_anchor, _net_elapsed / _net.close_seconds)
			_net.show_open(_net_anchor, net_radius, _net_elapsed / _net.close_seconds)
			if _net_elapsed >= _net.close_seconds:
				_resolve_net()
				_net_phase = NetPhase.RESULT
				_net_elapsed = 0.0
				_net.show_result(_net_anchor, _net_caught_count)
		NetPhase.RESULT:
			_net_elapsed += delta
			_net.show_result(_net_anchor, _net_caught_count)
			if _net_elapsed >= net_result_seconds:
				_net_phase = NetPhase.IDLE
		NetPhase.IDLE:
			if _active_tool != ToolMode.NET:
				_net.hide()
			elif run.can_cast_net():
				_net.show_preview(_tool_pointer, net_radius)
			else:
				_net.show_cooldown(
					_tool_pointer,
					net_radius,
					run.net_cooldown_remaining,
					run.settings.net_cooldown_seconds
				)


func _resolve_net() -> void:
	var candidates: Array[PrototypeSlime] = []
	var radius_squared: float = run.get_net_radius() * run.get_net_radius()
	for slime: PrototypeSlime in _slimes:
		if (
			slime.can_net_capture()
			and slime.get_capture_point().distance_squared_to(_net_anchor) <= radius_squared
		):
			candidates.append(slime)
	candidates.sort_custom(_is_nearer_to_net)
	var caught_count: int = mini(candidates.size(), run.get_net_capacity())
	var source_ids: Array[int] = []
	var rewards: Array[int] = []
	var populations: Array[int] = []
	for index: int in range(caught_count):
		var slime: PrototypeSlime = candidates[index]
		source_ids.append(slime.nest_id)
		rewards.append(slime.reward)
		populations.append(slime.population_units)
		_slimes.erase(slime)
		_capture_targets.erase(slime)
		slime.consumed = true
		slime.hide()
		slime.set_process(false)
		slime.queue_free()
	var reward: int = run.collect_net_batch(source_ids, rewards, populations)
	_net_caught_count = caught_count
	if reward > 0:
		_play_collection_reward(reward, _net_anchor)
		if _monster_audio.is_ready():
			_monster_audio.candy_from_net()
		else:
			_collect_sound.pitch_scale = 0.75
			_collect_sound.play()


func _is_nearer_to_net(first: PrototypeSlime, second: PrototypeSlime) -> bool:
	return (
		first.get_capture_point().distance_squared_to(_net_anchor)
		< second.get_capture_point().distance_squared_to(_net_anchor)
	)


func _can_collect(pointer: Vector2, radius: float) -> bool:
	var viewport_position: Vector2 = _world.get_global_transform_with_canvas() * pointer
	return (
		_window_has_focus
		and not _view.is_overview()
		and not _view.is_transitioning()
		and get_viewport_rect().has_point(viewport_position)
		and not _view.is_dragging()
		and not _layout.is_over_ui(viewport_position)
		and not _is_over_selected_nest(viewport_position)
		and pointer.length() + radius >= _planet.get_inner_radius(pointer.angle())
		and pointer.length() - radius <= _planet.get_outer_radius(pointer.angle())
	)


func _select_tool(tool: ToolMode) -> void:
	if tool == ToolMode.NET and not run.net_unlocked:
		_layout._show_quick_upgrade(1)
		return
	_capture_at(0.0, _tool_pointer, false)
	_was_holding = Input.is_mouse_button_pressed(MOUSE_BUTTON_LEFT)
	_active_tool = tool
	_pipe.visible = tool == ToolMode.PIPE
	_net.visible = tool == ToolMode.NET or _net_phase != NetPhase.IDLE
	_refresh_hud()


func _unhandled_key_input(event: InputEvent) -> void:
	if event is InputEventKey:
		var key: InputEventKey = event as InputEventKey
		if key.pressed and not key.echo:
			if key.keycode == KEY_1:
				_select_tool(ToolMode.PIPE)
				get_viewport().set_input_as_handled()
			elif key.keycode == KEY_2:
				_select_tool(ToolMode.NET)
				get_viewport().set_input_as_handled()


func _input(event: InputEvent) -> void:
	if not _view.is_dragging():
		return
	if event is InputEventMouseMotion:
		_view.drag_to((event as InputEventMouseMotion).position)
		get_viewport().set_input_as_handled()
	elif event is InputEventMouseButton:
		var button: InputEventMouseButton = event as InputEventMouseButton
		if button.button_index == MOUSE_BUTTON_RIGHT and not button.pressed:
			_view.end_drag()
			get_viewport().set_input_as_handled()
		elif button.button_index == MOUSE_BUTTON_LEFT:
			_view_blocks_tool_until_release = true
			get_viewport().set_input_as_handled()


func _unhandled_input(event: InputEvent) -> void:
	if not event is InputEventMouseButton:
		return
	var button: InputEventMouseButton = event as InputEventMouseButton
	if _layout.is_over_ui(button.position):
		return
	if button.button_index == MOUSE_BUTTON_LEFT and button.pressed:
		if (
			not _window_has_focus
			or not _view.is_overview()
			or _view.is_transitioning()
			or _view.is_dragging()
			or not get_viewport_rect().has_point(button.position)
		):
			return
		var bubble: OverviewEcology.Bubble = _overview.get_bubble_at(button.position)
		if bubble == null:
			return
		var surface_angle: float = bubble.cluster.angle
		_cancel_view_drag()
		_view.focus_surface(surface_angle)
		get_viewport().set_input_as_handled()
	elif button.button_index == MOUSE_BUTTON_RIGHT and button.pressed:
		var on_planet: bool = _view.contains_planet_body(button.position)
		var can_start_drag: bool = not on_planet if _view.is_overview() else on_planet
		if (
			not _window_has_focus
			or not get_viewport_rect().has_point(button.position)
			or not can_start_drag
			or _view.is_transitioning()
			or _is_over_selected_nest(button.position)
		):
			return
		_view_blocks_tool_until_release = true
		_clear_nest_selection()
		_capture_at(0.0, _tool_pointer, false)
		_view.begin_drag(button.position)
		get_viewport().set_input_as_handled()
	elif button.pressed and button.button_index in [MOUSE_BUTTON_WHEEL_UP, MOUSE_BUTTON_WHEEL_DOWN]:
		var steps: float = 1.0 if button.button_index == MOUSE_BUTTON_WHEEL_UP else -1.0
		if _view.is_overview() != (steps < 0.0):
			_view_blocks_tool_until_release = true
			_clear_nest_selection()
			_capture_at(0.0, _tool_pointer, false)
		_view.zoom_steps(steps * button.factor)
		get_viewport().set_input_as_handled()


func _cancel_view_drag() -> void:
	_overview.update_hover(Vector2.ZERO, false)
	_view.end_drag()
	_planet_audio.update_rotation(0.0, false, _world.rotation)
	_view_blocks_tool_until_release = true
	_was_holding = false
	_clear_nest_selection()
	_capture_at(0.0, _tool_pointer, false)


func _on_window_focus_exited() -> void:
	_window_has_focus = false
	_cancel_view_drag()
	_capture_at(0.0, _tool_pointer, false)
	_pipe.hide()


func _on_window_focus_entered() -> void:
	_window_has_focus = true


func _apply_layout() -> void:
	var play_rect: Rect2 = _layout.apply_layout(get_viewport_rect().size)
	_view.configure(play_rect, _planet.radius)
	_fit_activity_hole()
	var screen_half_angle: float = _get_roaming_screen_half_angle()
	for slime: PrototypeSlime in _slimes:
		slime.configure_roaming(screen_half_angle)
		slime.refresh_surface_bounds()


func _fit_activity_hole() -> void:
	# Use the near endpoint even in overview: changing cameras must not change geography.
	var screen: Vector2 = get_viewport_rect().size
	var screen_radius: float = screen.x * _view.near_radius_ratio
	var center: Vector2 = Vector2(
		screen.x * (0.5 + _view.near_horizontal_offset_ratio),
		screen.y * _view.near_horizon_ratio + screen_radius
	)
	var clearance: Rect2 = _layout.get_tool_clearance_rect()
	var hole_radius: float = 0.0
	for corner: Vector2 in [
		clearance.position,
		clearance.end,
		Vector2(clearance.position.x, clearance.end.y),
		Vector2(clearance.end.x, clearance.position.y)
	]:
		hole_radius = maxf(hole_radius, center.distance_to(corner))
	var near_scale: float = screen_radius / (_planet.radius * _view.near_surface_radius_ratio)
	_planet.inner_radius_ratio = clampf((hole_radius / near_scale + 1.0) / _planet.radius, 0.60, 0.95)


func _get_roaming_screen_half_angle() -> float:
	return _view.get_near_screen_half_angle(_planet.radius)


func _sync_view_presentation() -> void:
	_clear_nest_selection()
	_capture_at(0.0, _tool_pointer, false)
	var near_view: bool = not _view.is_overview()
	%InputHint.text = (
		"悬停吸取 · 左键投网 · 右键拖动星球 · 滚轮切换视图" if near_view else "点击气泡进入近景 · 右键拖动空白处 · 滚轮返回近景"
	)
	if not near_view or _view.is_transitioning():
		_pipe.hide()
		_net.hide()
	var crust_changed: bool = _planet.set_near_view(near_view)
	for slime: PrototypeSlime in _slimes:
		slime.presentation_scale = _view.near_slime_scale
	for nest: NestView in _nest_views:
		nest.presentation_scale = _view.near_nest_scale
	for region: GovernedRegion in _regions:
		if crust_changed:
			region.refresh_surface()
	for trail: MucusField in _mucus_trails:
		if crust_changed:
			trail.refresh_surface()
	for area: NestMucusArea in _nest_mucus_areas:
		if crust_changed:
			area.refresh_surface()
	_refresh_overview()
	_sync_view_projection()


func _sync_view_projection() -> void:
	var blend: float = _view.near_blend
	for layer: Node2D in [_slime_root, _nests, _mucus_root, _effects]:
		layer.visible = blend > 0.0
		layer.modulate.a = blend
	_overview.set_view_opacity(1.0 - blend)


func restart_run() -> void:
	_layout.close_panels()
	_giant_harvest = null
	if _completion_tween != null:
		_completion_tween.kill()
	if _status_tween != null:
		_status_tween.kill()
	for container: Node2D in [_nests, _region_root, _slime_root, _effects, _mucus_root]:
		for child: Node in container.get_children():
			container.remove_child(child)
			child.queue_free()
	_nest_views.clear()
	_regions.clear()
	_mucus_trails.clear()
	_active_mucus_trails.clear()
	_nest_mucus_areas.clear()
	_slimes.clear()
	_giant_check_elapsed = 0.0
	_capture_targets.clear()
	_vacuum_audio.stop_now()
	_pipe.reset_transport()
	selected_nest_id = -1
	_was_holding = false
	_view_blocks_tool_until_release = false
	_view.reset_view()
	_net_phase = NetPhase.IDLE
	_net_elapsed = 0.0
	_net_caught_count = 0
	_active_tool = ToolMode.PIPE
	_net.hide()
	_pipe.show()
	_spawn_directions.clear()
	_completion.hide()
	_status_label.text = ""
	_status_label.modulate.a = 1.0
	_prepare_nest_sites()
	var spawn_positions: Array[Vector2] = []
	for index: int in range(run.settings.initial_nests):
		# Keep the opening pair as close to the near-view center as their full growth allows.
		var offset: float = _nest_site_jitter if index == 0 else -_nest_site_jitter
		var angle: float = _nest_site_angles[index] + offset
		spawn_positions.append(_planet.get_nest_position(angle))
	_site_random.randomize()
	# The opening nests are already there when play starts; only later nests "appear".
	_opening_nests = true
	run.start_run(spawn_positions)
	_opening_nests = false
	_tool_pointer = _world.to_local(get_global_mouse_position())
	_pipe.position = _tool_pointer
	_refresh_hud()


func _capture_at(delta: float, target: Vector2, active: bool) -> void:
	var radius: float = run.get_pipe_radius()
	var radius_squared: float = radius * radius
	var nearest: PrototypeSlime = null
	var nearest_distance: float = radius_squared
	if active and not _capture_targets.is_empty():
		var previous: PrototypeSlime = _capture_targets[0]
		if (
			is_instance_valid(previous)
			and previous.can_capture()
			and previous.get_capture_point().distance_squared_to(target) <= radius_squared
		):
			nearest = previous
	if active and nearest == null:
		for candidate: PrototypeSlime in _slimes:
			var distance: float = candidate.get_capture_point().distance_squared_to(target)
			if candidate.can_capture() and distance <= nearest_distance:
				nearest = candidate
				nearest_distance = distance
	# Only a former target needs its partial capture cancelled. Unrelated actors
	# must not be redrawn or copied into a new population array every tool tick.
	for previous: PrototypeSlime in _capture_targets:
		if is_instance_valid(previous) and previous != nearest:
			previous.capture_progress = 0.0
			previous.release_capture(delta)
			_stop_giant_harvest()
	_capture_targets.clear()
	_vacuum_audio.update(delta, nearest != null, active and _is_on_ground_mucus(target))
	_pipe.set_capture_engaged(nearest != null)
	if nearest == null:
		_stop_giant_harvest()
		return
	_capture_targets.append(nearest)
	nearest.on_mucus = _is_on_ground_mucus(nearest.position)
	var capture_delta: float = delta
	var peel_seconds: float = run.get_pipe_capture_seconds()
	if nearest.is_anchored():
		capture_delta = maxf(0.0, delta - (1.0 - nearest.peel_progress) * peel_seconds)
	if not nearest.pull_off_mucus(delta, target, peel_seconds):
		return
	var completed: bool = nearest.apply_capture(capture_delta, peel_seconds, target)
	if nearest.population_units > 1:
		_update_giant_harvest(nearest)
	if not completed:
		return
	_stop_giant_harvest()
	var before: int = run.candy
	var accepted: bool = run.collect_slime(
		nearest.nest_id, nearest.reward, nearest.population_units
	)
	assert(accepted, "Collected monster must belong to its source population.")
	_pipe.play_capture()
	_pipe.set_capture_engaged(false)
	if nearest.species == PrototypeSlime.Species.DRILL:
		_play_drill_treasure(run.candy - before, nearest.get_capture_point())
	else:
		_play_collection_reward(run.candy - before, nearest.get_capture_point())
	_capture_targets.clear()
	_slimes.erase(nearest)
	nearest.hide()
	nearest.set_process(false)
	nearest.queue_free()
	if _monster_audio.is_ready():
		_monster_audio.monster_sucked(run.combo_count)
	else:
		_collect_sound.pitch_scale = randf_range(0.92, 1.12)
		_collect_sound.play()


func _capture_seconds_for(slime: PrototypeSlime) -> float:
	var seconds: float = run.get_pipe_capture_seconds()
	# Total time estimate; actual capture handles detachment and suction separately.
	if slime.detached_remaining <= 0.0 and _is_on_ground_mucus(slime.position):
		return seconds * 2.0
	return seconds


func _is_on_ground_mucus(point: Vector2) -> bool:
	for area: NestMucusArea in _nest_mucus_areas:
		if area.contains_ground_point(point):
			return true
	for patch: MucusField in _mucus_trails:
		if patch.contains_ground_point(point):
			return true
	return false


func _advance_ground_mucus(delta: float) -> void:
	for index: int in range(_mucus_trails.size() - 1, -1, -1):
		var trail: MucusField = _mucus_trails[index]
		if not trail.advance(delta, false):
			_retire_mucus_trail(trail)
	var emitting_ids: Dictionary = {}
	for slime: PrototypeSlime in _slimes:
		if slime.can_emit_ground_mucus():
			emitting_ids[slime.get_instance_id()] = true
	# Drop stale ownership before allocating: only inactive history may be evicted.
	for actor_id: int in _active_mucus_trails.keys():
		if not emitting_ids.has(actor_id):
			_active_mucus_trails.erase(actor_id)
	for slime: PrototypeSlime in _slimes:
		var actor_id: int = slime.get_instance_id()
		if emitting_ids.has(actor_id):
			var trail: MucusField = _active_mucus_trails.get(actor_id) as MucusField
			if (
				trail != null
				and (
					trail.get_ground_points()[-1].distance_to(slime.position)
					> run.settings.mucus_trail_max_length * 0.5
				)
			):
				_active_mucus_trails.erase(actor_id)
				trail = null
			if trail == null:
				trail = _start_mucus_trail(slime)
			trail.append_ground_point(slime.position, false)
	_trim_mucus_history()
	for trail: MucusField in _mucus_trails:
		trail.refresh_surface(false, trail.is_detail_on_screen())
	for slime: PrototypeSlime in _slimes:
		slime.on_mucus = _is_on_ground_mucus(slime.position)


func _start_mucus_trail(slime: PrototypeSlime) -> MucusField:
	_active_mucus_trails.erase(slime.get_instance_id())
	_trim_mucus_history(1)
	var trail: MucusField = MUCUS_SCENE.instantiate() as MucusField
	_mucus_root.add_child(trail)
	trail.source_actor_id = slime.get_instance_id()
	trail.configure(
		_planet,
		slime.position,
		slime.nest_id,
		run.settings.mucus_trail_half_width,
		run.settings.mucus_trail_lifetime,
		run.settings.mucus_trail_max_length,
		run.settings.mucus_trail_sample_spacing
	)
	_mucus_trails.append(trail)
	_active_mucus_trails[trail.source_actor_id] = trail
	return trail


func _trim_mucus_history(reserved: int = 0) -> void:
	# Live emitters each keep their ribbon. The history budget can grow to the
	# live-source count, then shrinks as sources stop; it never caps population.
	var retained_limit: int = maxi(
		run.settings.mucus_trail_limit, _active_mucus_trails.size() + reserved
	)
	if _mucus_trails.size() + reserved <= retained_limit:
		return
	for trail: MucusField in _mucus_trails.duplicate():
		if _active_mucus_trails.get(trail.source_actor_id) == trail:
			continue
		_retire_mucus_trail(trail)
		if _mucus_trails.size() + reserved <= retained_limit:
			break


func _retire_mucus_trail(trail: MucusField) -> void:
	_mucus_trails.erase(trail)
	if _active_mucus_trails.get(trail.source_actor_id) == trail:
		_active_mucus_trails.erase(trail.source_actor_id)
	trail.queue_free()


func _refresh_overview() -> void:
	_overview_sample_elapsed = 0.0
	var positions: PackedVector2Array = PackedVector2Array()
	var kinds: PackedInt32Array = PackedInt32Array()
	var populations: PackedInt32Array = PackedInt32Array()
	for actor: PrototypeSlime in _slimes:
		if not actor.consumed and actor.species != PrototypeSlime.Species.DRILL:
			positions.append(actor.position)
			kinds.append(int(actor.species))
			populations.append(actor.population_units)
	_overview.update_ecology(
		positions,
		kinds,
		_view.is_overview() or _view.is_transitioning(),
		get_viewport_rect().size,
		populations
	)


func _play_collection_reward(reward: int, source_position: Vector2) -> void:
	if _view.is_overview():
		return
	var effect: CollectionEffect = collection_scene.instantiate() as CollectionEffect
	_effects.add_child(effect)
	effect.top_level = true
	effect.global_transform = Transform2D.IDENTITY
	var origin: Vector2 = _world.to_global(source_position)
	var destination: Vector2 = (
		_candy_label.get_global_transform_with_canvas() * (_candy_label.size * 0.5)
	)
	effect.play(origin, destination, reward)


func _update_giant_harvest(slime: PrototypeSlime) -> void:
	if _giant_harvest == null:
		_giant_harvest = giant_harvest_scene.instantiate() as GiantHarvestEffect
		_effects.add_child(_giant_harvest)
		_giant_harvest.top_level = true
		_giant_harvest.global_transform = Transform2D.IDENTITY
	var destination: Vector2 = (
		_candy_label.get_global_transform_with_canvas() * (_candy_label.size * 0.5)
	)
	_giant_harvest.update_capture(
		_world.to_global(slime.get_capture_point()), destination, slime.capture_progress
	)


func _play_drill_treasure(reward: int, source_position: Vector2) -> void:
	var effect: DrillTreasure = TREASURE_SCENE.instantiate() as DrillTreasure
	_effects.add_child(effect)
	effect.top_level = true
	effect.global_transform = Transform2D.IDENTITY
	var destination: Vector2 = (
		_candy_label.get_global_transform_with_canvas() * (_candy_label.size * 0.5)
	)
	effect.play(_world.to_global(source_position), destination, reward, run.get_base_value())


func _stop_giant_harvest() -> void:
	if _giant_harvest != null:
		_giant_harvest.finish()
		_giant_harvest = null


func _advance_monster_chatter(delta: float) -> void:
	_population_by_species.clear()
	for slime: PrototypeSlime in _slimes:
		if slime.can_capture():
			_population_by_species[slime.species] = (
				int(_population_by_species.get(slime.species, 0)) + 1
			)
	_monster_audio.update_chatter(delta, _population_by_species)


func _prepare_nest_sites() -> void:
	var measuring_view: NestView = nest_scene.instantiate() as NestView
	_nests.add_child(measuring_view)
	var maximum_width: float = (
		measuring_view.get_maximum_footprint_width() * _view.near_nest_scale.x
	)
	_nests.remove_child(measuring_view)
	measuring_view.free()
	_nest_site_distance = maxf(
		maximum_width + run.settings.nest_spacing_margin, run.settings.nest_min_distance
	)
	# Relief never exceeds its configured amplitude; use this lower radius bound for every heading.
	var minimum_radius: float = (
		_planet.radius * (PlanetSurface.SURFACE_RADIUS_RATIO - _planet.edge_relief_ratio)
		- _planet.nest_edge_inset
	)
	assert(_nest_site_distance < minimum_radius * 2.0, "The planet must fit two fully grown nests.")
	var minimum_angle: float = 2.0 * asin(_nest_site_distance / (minimum_radius * 2.0))
	var site_count: int = int(floor(TAU / minimum_angle))
	assert(site_count >= run.settings.initial_nests, "The planet must fit all opening nests.")
	var angle_step: float = TAU / float(site_count)
	_nest_site_jitter = (angle_step - minimum_angle) * 0.5
	_nest_site_angles.clear()
	for index: int in range(site_count):
		_nest_site_angles.append(-PI / 2.0 + (float(index) - 0.5) * angle_step)


func _on_nest_spawn_requested(species: NestState.Species) -> void:
	var points: Array[Vector2] = []
	var weights: Array[float] = []
	var total_weight: float = 0.0
	var angle_step: float = TAU / float(_nest_site_angles.size())
	for site_angle: float in _nest_site_angles:
		var angle: float = (
			site_angle + _site_random.randf_range(-_nest_site_jitter, _nest_site_jitter)
		)
		var point: Vector2 = _planet.get_nest_position(angle)
		var legal: bool = true
		var weight: float = 1.0
		for nest: NestState in run.nests:
			var distance: float = nest.position.distance_to(point)
			var site_offset: float = absf(wrapf(nest.position.angle() - site_angle, -PI, PI))
			if site_offset < angle_step * 0.5 or distance < _nest_site_distance:
				legal = false
				break
			if (
				nest.species == species
				and not nest.is_tamed
				and distance < run.settings.same_species_soft_distance
			):
				weight *= run.settings.same_species_near_weight
		if legal:
			points.append(point)
			weights.append(weight)
			total_weight += weight
	if points.is_empty():
		run.resolve_nest_spawn(Vector2.ZERO, false)
		return
	var roll: float = _site_random.randf() * total_weight
	var selected: Vector2 = points.back()
	for index: int in range(points.size()):
		roll -= weights[index]
		if roll <= 0.0:
			selected = points[index]
			break
	run.resolve_nest_spawn(selected)


func _on_nest_added(nest: NestState) -> void:
	var region: GovernedRegion = REGION_SCENE.instantiate() as GovernedRegion
	_region_root.add_child(region)
	region.configure(_planet, nest.position)
	region.species = nest.species
	_regions.append(region)
	if nest.species == NestState.Species.MUCUS:
		var area: NestMucusArea = NEST_MUCUS_SCENE.instantiate() as NestMucusArea
		_mucus_root.add_child(area)
		area.configure(
			_planet,
			nest.position,
			nest.nest_id,
			region.region_radius * run.settings.mucus_nest_coverage_multiplier
		)
		_nest_mucus_areas.append(area)
	var view: NestView = nest_scene.instantiate() as NestView
	view.surface = _planet
	_nests.add_child(view)
	view.position = nest.position
	view.setup(nest.nest_id)
	view.rotation = _planet.get_nest_rotation(nest.position.angle())
	view.configure_species(nest.species)
	view.presentation_scale = _view.near_nest_scale
	view.update_state(nest.level, nest.is_tamed, run.settings.nest_upgrade_costs.size())
	_nest_views.append(view)
	if not _opening_nests:
		_monster_audio.nest_appeared(nest.species)
	_refresh_hud()


func _on_nest_changed(nest: NestState) -> void:
	_nest_views[nest.nest_id - 1].update_state(
		nest.level, nest.is_tamed, run.settings.nest_upgrade_costs.size()
	)
	_regions[nest.nest_id - 1].stage = nest.level
	_queue_hud_refresh()


func _on_slime_requested(nest_id: int) -> void:
	var nest: NestState = run.get_nest(nest_id)
	_nest_views[nest_id - 1].pulse_spawn()
	_monster_audio.monster_spawned(nest.species)
	var actor_scene: PackedScene = (
		DRILL_SCENE if nest.species == NestState.Species.DRILL else slime_scene
	)
	var slime: PrototypeSlime = actor_scene.instantiate() as PrototypeSlime
	_slime_root.add_child(slime)
	slime.setup(nest_id, nest.position, _planet, _get_roaming_screen_half_angle())
	slime.presentation_scale = _view.near_slime_scale
	var direction_index: int = int(_spawn_directions.get(nest_id, 0))
	_spawn_directions[nest_id] = direction_index + 1
	var species: PrototypeSlime.Species = nest.species as PrototypeSlime.Species
	var valuable: bool = (
		nest.species != NestState.Species.DRILL
		and run.valuable_level > 0
		and direction_index % run.settings.valuable_spawn_every == 0
	)
	var reward: int = run.get_capture_reward(nest.species, valuable)
	slime.configure_species(species, valuable, reward)
	var direction_angle: float = (
		float(direction_index) * 2.399963 + nest.position.angle() + randf_range(-0.14, 0.14)
	)
	slime.launch(Vector2.from_angle(direction_angle))
	_slimes.append(slime)


func _advance_giant_fusion(delta: float) -> void:
	if (
		not run.giant_unlocked
		or _view.is_overview()
		or _view.is_transitioning()
		or _view.is_dragging()
	):
		_giant_check_elapsed = 0.0
		return
	_giant_check_elapsed += delta
	if _giant_check_elapsed < run.settings.giant_check_interval:
		return
	_giant_check_elapsed = 0.0
	var viewport: Rect2 = get_viewport_rect()
	var offscreen_nests: Array[int] = []
	for nest_view: NestView in _nest_views:
		if not viewport.intersects(nest_view.get_hover_rect()):
			offscreen_nests.append(nest_view.nest_id)
	var candidates: Array[PrototypeSlime] = []
	for actor: PrototypeSlime in _slimes:
		if not actor.can_fuse() or not offscreen_nests.has(actor.nest_id):
			continue
		if viewport.intersects(actor.get_visual_rect()) or _capture_targets.has(actor):
			continue
		if (
			_net_phase in [NetPhase.CASTING, NetPhase.CLOSING]
			and actor.get_capture_point().distance_to(_net_anchor) <= run.get_net_radius()
		):
			continue
		candidates.append(actor)
	var activity_radius: float = (
		PrototypeSlime.get_activity_radius(_planet.radius, _get_roaming_screen_half_angle())
		* run.settings.giant_activity_radius_multiplier
	)
	for plan: GiantFusion.Plan in GiantFusion.plan_batches(run, candidates, activity_radius):
		_apply_giant_fusion(plan, viewport)


func _apply_giant_fusion(plan: GiantFusion.Plan, viewport: Rect2) -> void:
	var owner: NestState = run.get_nest(plan.owner_id)
	var giant: PrototypeSlime = giant_slime_scene.instantiate() as PrototypeSlime
	_slime_root.add_child(giant)
	giant.setup(owner.nest_id, owner.position, _planet, _get_roaming_screen_half_angle())
	giant.presentation_scale = _view.near_slime_scale
	giant.configure_species(owner.species as PrototypeSlime.Species, false, 0)
	giant.configure_fusion(
		plan.actors.size(), plan.value_units, run.get_base_value() * plan.value_units
	)
	var inward: Vector2 = -owner.position.normalized()
	var tangent: Vector2 = inward.orthogonal()
	giant.restore_to_surface(
		owner.position + inward * 35.0 + tangent * _site_random.randf_range(-28.0, 28.0)
	)
	# A large body can reach the screen while its nest is already outside it.
	# Defer that batch until it is safe to replace all of its participants.
	if viewport.intersects(giant.get_visual_rect()):
		giant.hide()
		giant.queue_free()
		return
	var accepted: bool = run.fuse_population(plan.contributions, plan.owner_id)
	assert(accepted, "A fusion plan must retain its exact source population until settlement.")
	for actor: PrototypeSlime in plan.actors:
		_slimes.erase(actor)
		actor.consumed = true
		actor.hide()
		actor.set_process(false)
		actor.queue_free()
	_slimes.append(giant)
	_refresh_overview()


func _refresh_monster_rewards() -> void:
	for slime: PrototypeSlime in _slimes:
		slime.reward = (
			run.get_base_value() * slime.fused_value_units
			if slime.population_units > 1
			else run.get_capture_reward(slime.species as NestState.Species, slime.high_value)
		)


func _on_automatic_income_received(nest_id: int, _amount: int) -> void:
	if _view.is_overview():
		return
	_nest_views[nest_id - 1].pulse_automatic()


func _select_nest(nest_id: int) -> void:
	selected_nest_id = nest_id
	_refresh_hud()
	_layout.show_nest_details(_nest_views[nest_id - 1].get_hover_rect())


func _update_nest_hover(viewport_position: Vector2) -> void:
	if (
		_view.is_overview()
		or _view.is_transitioning()
		or _view.is_dragging()
		or _layout.is_technology_open()
	):
		_clear_nest_selection()
		return
	if selected_nest_id >= 0 and _layout.is_over_nest_details(viewport_position):
		_layout.show_nest_details(_nest_views[selected_nest_id - 1].get_hover_rect())
		return
	if _layout.is_over_ui(viewport_position):
		_clear_nest_selection()
		return
	for view: NestView in _nest_views:
		if view.contains_viewport_point(viewport_position):
			if selected_nest_id != view.nest_id:
				_select_nest(view.nest_id)
			else:
				_layout.show_nest_details(view.get_hover_rect())
			return
	if selected_nest_id >= 0:
		var selected_view: NestView = _nest_views[selected_nest_id - 1]
		if selected_view.get_hover_rect().has_point(viewport_position):
			_layout.show_nest_details(selected_view.get_hover_rect())
			return
	_clear_nest_selection()


func _is_over_selected_nest(viewport_position: Vector2) -> bool:
	return (
		selected_nest_id >= 0
		and _nest_views[selected_nest_id - 1].contains_viewport_point(viewport_position)
	)


func _clear_nest_selection() -> void:
	if selected_nest_id >= 0:
		selected_nest_id = -1
	_layout.hide_nest_details()


func _queue_hud_refresh() -> void:
	if _hud_refresh_queued:
		return
	_hud_refresh_queued = true
	_refresh_hud.call_deferred()


func _refresh_hud() -> void:
	_hud_refresh_queued = false
	_refresh_overview()
	_candy_label.text = str(run.candy)
	_passive_label.text = "%s DPS" % String.num(run.get_passive_income(), 1).trim_suffix(".0")
	_progress_label.text = "已自动化 %d / %d" % [run.completed_nests, run.generated_nests]
	_progress_bar.max_value = maxi(1, run.generated_nests)
	_progress_bar.value = run.completed_nests
	_tool_level_label.text = (
		"Lv. %d" % ((run.pipe_level if _active_tool == ToolMode.PIPE else run.net_level) + 1)
	)
	_pipe_button.button_pressed = _active_tool == ToolMode.PIPE
	_net_button.button_pressed = _active_tool == ToolMode.NET
	_quick_pipe_button.button_pressed = _active_tool == ToolMode.PIPE
	_quick_net_button.button_pressed = _active_tool == ToolMode.NET
	_pipe_button.disabled = false
	_net_button.disabled = not run.net_unlocked
	_quick_pipe_button.disabled = false
	_quick_net_button.disabled = false
	_layout.refresh_progression(run)
	var tool_cost: int = (
		run.get_pipe_upgrade_cost() if _active_tool == ToolMode.PIPE else run.get_net_upgrade_cost()
	)
	if _active_tool == ToolMode.PIPE:
		_tool_stats_label.text = "处理 %.2f 秒 / 只" % run.get_pipe_capture_seconds()
		if tool_cost >= 0:
			_tool_stats_label.text += (
				"\n升级后 %.2f 秒 / 只" % run.settings.pipe_capture_seconds[run.pipe_level + 1]
			)
	else:
		_tool_stats_label.text = "容量 %d 只" % run.get_net_capacity()
		if tool_cost >= 0:
			_tool_stats_label.text += (
				"\n升级后 %d 只" % run.settings.net_capacities[run.net_level + 1]
			)
	_tool_button.disabled = tool_cost < 0 or run.candy < tool_cost
	_tool_button.text = (
		"已满级"
		if tool_cost < 0
		else "%s升级 · %d 糖果" % ["速度" if _active_tool == ToolMode.PIPE else "容量", tool_cost]
	)
	_tool_button.tooltip_text = ""
	var nest: NestState = run.get_nest(selected_nest_id)
	if nest == null:
		_nest_title_label.text = "巢穴"
		_nest_level_label.text = "悬停巢穴查看升级"
		_nest_benefit_label.text = ""
		_nest_button.text = "驯化"
		_nest_button.disabled = true
		return
	_nest_title_label.text = ("%s巢穴 %02d" % [["史莱姆", "黏液怪", "钻头怪"][nest.species], nest.nest_id])
	if nest.is_tamed:
		_nest_level_label.text = "完全自动化 · 剩余生物 %d" % nest.alive_slimes
		_nest_benefit_label.text = "停止产怪 · 每秒 %.1f 糖果" % run.get_automatic_income_per_nest()
		_nest_button.text = "自动产糖中"
		_nest_button.disabled = true
		return
	var stage_names: Array[String] = ["野生", "培育中", "强化培育"]
	_nest_level_label.text = (
		"%s · 生物 %d / %d"
		% [stage_names[nest.level], nest.alive_slimes, run.get_nest_population_limit(nest.nest_id)]
	)
	var next_level: int = nest.level + 1
	if next_level == run.settings.nest_upgrade_costs.size():
		_nest_benefit_label.text = "停止产怪 · 每秒 %.1f 糖果" % run.get_automatic_income_per_nest()
	else:
		_nest_benefit_label.text = (
			"间隔 %.0f → %.0f 秒（±%.0f 秒）\n上限 %d → %d 只"
			% [
				run.settings.spawn_intervals[nest.level],
				run.settings.spawn_intervals[next_level],
				run.settings.spawn_interval_jitter,
				run.get_nest_population_limit(nest.nest_id),
				run.settings.nest_population_limits[next_level]
			]
		)
		if nest.species == NestState.Species.DRILL:
			_nest_benefit_label.text = (
				"每次 1 只 · 冒头时可吸取\n上限 %d → %d 只"
				% [
					run.get_nest_population_limit(nest.nest_id),
					run.settings.drill_population_limits[next_level]
				]
			)
	var nest_cost: int = run.get_nest_upgrade_cost(selected_nest_id)
	var requirement: String = run.get_nest_upgrade_requirement(selected_nest_id)
	_nest_button.text = "治理 · %d 糖果" % nest_cost if requirement.is_empty() else requirement
	_nest_button.disabled = run.candy < nest_cost or not requirement.is_empty()


func _register_purchase_sounds() -> void:
	var page: TechnologyPage = $HUD/Interface/Technology
	UiAudio.register_purchase(page.purchase, _is_technology_page_unaffordable.bind(page))
	for index: int in range(2):
		var panel: Node = $HUD/Interface/PipeUpgrade if index == 0 else $HUD/Interface/NetUpgrade
		UiAudio.register_purchase(
			panel.get_node("Content/Purchase"),
			_is_technology_unaffordable.bind(DiskDemoLayout.BRANCH_IDS[index])
		)
	UiAudio.register_purchase(_tool_button, _is_tool_unaffordable)


# Technology purchases play Level Up; the original WAV remains the fallback.
func _play_level_up() -> void:
	if UiAudio.is_ready():
		UiAudio.level_up()
	else:
		_upgrade_sound.play()


func _is_technology_unaffordable(id: String) -> bool:
	var cost: int = run.get_technology_cost(id)
	return cost >= 0 and run.candy < cost and run.get_technology_requirement(id).is_empty()


func _is_technology_page_unaffordable(page: TechnologyPage) -> bool:
	return _is_technology_unaffordable(page.selected_key)


func _is_tool_unaffordable() -> bool:
	return _is_technology_unaffordable("pipe" if _active_tool == ToolMode.PIPE else "net")


func _on_tool_upgrade() -> void:
	var upgraded: bool = run.upgrade_pipe() if _active_tool == ToolMode.PIPE else run.upgrade_net()
	if upgraded:
		_play_level_up()
		_show_status("管子处理更快了" if _active_tool == ToolMode.PIPE else "捕网容量增加了")


func _on_nest_upgrade() -> void:
	if run.upgrade_nest(selected_nest_id):
		var nest: NestState = run.get_nest(selected_nest_id)
		if nest.is_tamed:
			_tame_sound.play()
			_show_status("巢穴已自动产糖")
		else:
			_upgrade_sound.play()
			_show_status("巢穴培育升级")


func _on_quick_upgrade(tool: int) -> void:
	_on_technology_upgrade("pipe" if tool == 0 else "net")


func _on_technology_upgrade(technology_id: String) -> void:
	var unlocking_net: bool = technology_id in ["net", "net_unlock"] and not run.net_unlocked
	if run.purchase_technology(technology_id):
		_refresh_hud()
		_play_level_up()
		if unlocking_net:
			_show_status("捕网已解锁")
		else:
			_show_status("科技升级完成")


func _show_status(message: String) -> void:
	if _status_tween != null:
		_status_tween.kill()
	_status_label.text = message
	_status_label.modulate.a = 1.0
	_status_tween = create_tween()
	_status_tween.tween_interval(1.7)
	_status_tween.tween_property(_status_label, "modulate:a", 0.0, 0.5)


func _on_goal_completed() -> void:
	_refresh_hud()
	_completion_tween = create_tween()
	_completion_tween.tween_interval(1.5)
	_completion_tween.tween_callback(_show_completion)


func _show_completion() -> void:
	_layout.close_panels()
	_finish_sound.play()
	_completion_title.text = "整个星球，生生不息"
	_completion_detail.text = "全部 %d 座巢穴已自动化。\n持续产糖，你仍可捕获剩余生物与研究。" % run.generated_nests
	_completion.show()
	%ReplayButton.grab_focus()


func _close_victory() -> void:
	_completion.hide()
